//VARIABLES GO HERE




// CALLS FUNCTIONS ONCE PAGE HAS RENDERED
document.addEventListener('DOMContentLoaded', function () { 
    draw();
    drawCircles();
}, false);

////////////////////////////////////////////////////////////////////////////////
//YOUR FUNCTIONS GO HERE:
////////////////////////////////////////////////////////////////////////////////





function generateData() {

}


function draw() {
    

}

function drawCircles() {

}




